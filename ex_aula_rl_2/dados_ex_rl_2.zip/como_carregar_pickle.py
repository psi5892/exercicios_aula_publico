# Exemplo para carregar dados do pickle arquivo.pickle na variável x

import pickle

with open('arquivo.pickle', 'rb') as f:
    x = pickle.load(f)

